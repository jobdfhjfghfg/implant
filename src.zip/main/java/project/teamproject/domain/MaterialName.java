package project.teamproject.domain;

public enum MaterialName {

    TITANIUM,   // 티타늄

    SUS,   // 서스

    COBALT, // 코발트
    
//    추가 자재
    CAPSULE,   // 포장 캡슐
    
    BOX   // 포장 박스


}
