package project.teamproject.domain;

public enum ProductName {

    FIXTURE,   // 픽스쳐

    ABUTMENT,   // 어버트먼트

    COVERSCREW   // 커버스크류
}
