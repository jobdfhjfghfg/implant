package project.teamproject.controller;

public class SessionConst {

    public static final String LOGIN_MEMBER = "loginMember";
}
